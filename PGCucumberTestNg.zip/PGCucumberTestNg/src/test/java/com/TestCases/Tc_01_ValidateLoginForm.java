package com.TestCases;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.RunnerClass.CucumberRunner;
import com.ScreenFunctions.Login;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Tc_01_ValidateLoginForm extends CucumberRunner {
	
	@Given("^I login in BigCommerce site$")
	public void runBrowser() {
	 System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");  
		driver=new ChromeDriver();
	}
	
	@And("^i need to maximize it$")
	
	public void maximizeBrowser() {
		   
		driver.manage().window().maximize();
	}
	
	@When("^it maximizes enter the url$")
	
	public void enterURL()
	{
		driver.get("https://login.bigcommerce.com/login?_ga=2.66434216.7059407.1555513677-124167243.1554453828&_gac=1.241501878.1554453828.EAIaIQobChMIn-mH3Me44QIVg4-PCh2IVAZREAAYASAAEgIwsPD_BwE");
	}
	
	
	
	@Then("^I need to enter valid credentials$")
	public void EnterCredentials()
	{
		
		Login lgn=PageFactory.initElements(driver, Login.class);
		lgn.Login_Admin();
		
	}
	
	
	@When("I navigate to view store")
	public void i_navigate_to_view_store() {
		driver.findElement(By.xpath("//span[text()='View Store']")).click();  
		String parentWinHandle = driver.getWindowHandle();
		Set<String> winHandles = driver.getWindowHandles();
        for(String handle: winHandles){
            if(!handle.equals(parentWinHandle)){
            driver.switchTo().window(handle);
            System.out.println("Title of the new window: " +driver.getTitle());
            }
        }
	}

	@When("I add product")
	public void i_add_product() {
		WebDriverWait wait=new WebDriverWait(driver, 20);
		WebElement garden;
		garden= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='navPages-container']//a[text() ='Garden']")));
		garden.click();
		driver.findElement(By.xpath("//a[text() ='[Sample] Orbit Terrarium - Large']")).click();
		driver.findElement(By.xpath("//input[@value='Add to Cart']")).click();
	}
	@When("^I proceed for checkout$")
	public void i_proceed_for_checkout() throws Throwable {
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[normalize-space(text())='Proceed to checkout']")).click();
	}
	
	@Then("I will provide Shipping and billing details")
	public void i_will_provide_Shipping_and_billing_details() {
		
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("s.tanveer.kaamil@accenture.com");
		driver.findElement(By.xpath("//button[text()='Continue as guest']")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='firstNameInput']")).sendKeys("bigcom");
		driver.findElement(By.xpath("//input[@id='lastNameInput']")).sendKeys("test");
		driver.findElement(By.xpath("//input[@id='companyInput']")).sendKeys("ABC");

		driver.findElement(By.xpath("//input[@id='addressLine1Input']")).sendKeys("Divya sri");
		driver.findElement(By.xpath("//input[@id='addressLine2Input']")).sendKeys("orion");
		driver.findElement(By.xpath("//input[@id='cityInput']")).sendKeys("Hyderabad");
		
		driver.findElement(By.xpath("//select[@name='provinceCodeInput']/option[@label='Telangana']")).click();
		
		driver.findElement(By.xpath("//input[@id='postCodeInput']")).sendKeys("500084");
		driver.findElement(By.xpath("//input[@id='order-comments']")).sendKeys("Required delivery ASAP");
		WebDriverWait wait=new WebDriverWait(driver, 20);
		WebElement cont;
		cont= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space(text())='Continue']")));
		cont.click();
		driver.findElement(By.xpath("//input[@id='ccNumber']")).sendKeys("4111111111111111");
		driver.findElement(By.xpath("//input[@id='ccExpiry']")).sendKeys("12/22");
		
		driver.findElement(By.xpath("//input[@id='ccName']")).sendKeys("Sajida Tanveer");
		driver.findElement(By.xpath("//input[@id='ccCvv']")).sendKeys("123");
		driver.findElement(By.xpath("//button[normalize-space(text())='Place Order']")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("My order is successful")
	public void my_product_is_order_is_successful() {
		String Actualmsg="";
		Actualmsg=driver.findElement(By.xpath("//h1[@class='optimizedCheckout-headingPrimary']")).getText();

		
		System.out.println("Message"+Actualmsg);

        driver.quit();
 
	}



}

	
//}
